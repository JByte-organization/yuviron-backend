﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Yuviron.Domain.Enums;

public enum SubscriptionStatus
{
    Active = 1,
    Canceled = 2,
    Expired = 3
}
