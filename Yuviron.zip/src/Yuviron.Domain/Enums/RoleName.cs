﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Yuviron.Domain.Enums;

public enum RoleName
{
    User = 1,
    ManagementUser = 2,
    Admin = 3
}
