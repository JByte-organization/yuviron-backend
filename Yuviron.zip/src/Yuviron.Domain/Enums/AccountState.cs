﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Yuviron.Domain.Enums;

public enum AccountState
{
    Active = 1,
    Deleted = 2,
    Banned = 3
}