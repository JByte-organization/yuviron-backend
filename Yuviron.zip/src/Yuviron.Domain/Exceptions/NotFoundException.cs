﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Yuviron.Domain.Exceptions
{
    internal class NotFoundException
    {
    }
}
