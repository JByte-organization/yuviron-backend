﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Yuviron.Application.Features.Auth.Commands.Login
{
    internal class LoginCommand
    {
    }
}
