﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Yuviron.Application.Features.Playlists.Queries.GetUserPlaylists
{
    internal class GetUserPlaylistsQuery
    {
    }
}
