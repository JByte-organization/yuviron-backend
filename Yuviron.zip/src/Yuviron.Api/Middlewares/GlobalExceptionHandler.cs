﻿namespace Yuviron.Api.Middlewares
{
    public class GlobalExceptionHandler
    {
    }
}
