﻿namespace Yuviron.Api.Contracts.Common
{
    public class ErrorResponse
    {
    }
}
