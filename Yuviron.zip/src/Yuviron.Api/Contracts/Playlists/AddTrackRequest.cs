﻿namespace Yuviron.Api.Contracts.Playlists
{
    public class AddTrackRequest
    {
    }
}
