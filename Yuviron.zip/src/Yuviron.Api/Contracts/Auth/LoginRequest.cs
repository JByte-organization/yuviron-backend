﻿namespace Yuviron.Api.Contracts.Auth
{
    public class LoginRequest
    {
    }
}
