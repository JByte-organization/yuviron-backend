﻿namespace Yuviron.Api.Contracts.Auth
{
    public class RegisterRequest
    {
    }
}
